# Change Log

The node-oracledb change log has moved to [https://node-oracledb.readthedocs.io/en/latest/release_notes.html](https://node-oracledb.readthedocs.io/en/latest/release_notes.html).
