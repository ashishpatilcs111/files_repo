const crypto = require('crypto');
const axios = require('axios'); // Alternative to RestSharp

async function callEncryptedApi({
  in_timestamp,
  in_req,
  in_acct_no,
  in_url
}) {
  // Inputs needed:
  // - in_timestamp: Current timestamp (e.g., new Date().toISOString())
  // - in_req: Request ID (string)
  // - in_acct_no: Account number (string)
  // - in_url: API endpoint URL

  const plainText = JSON.stringify({
    reqTimestamp: in_timestamp,
    data: {
      requestType: "F7Enquiry",
      requestId: `req_${in_req}`,
      requestMaker: "10399",
      requestChecker1: "17105",
      requestChecker2: "16908",
      requestBranch: "822",
      accountNoCustNo: in_acct_no
    },
    vendor: "FEATSYSTEM",
    requestId: `req_${in_req}`,
    client: "BOM",
    chksum: "13456"
  });

  const encryptionkey = "asdfghjytrf45678";
  const ivString = "456753";

  // Encryption
  let encryptedText;
  try {
    const key = Buffer.from(encryptionkey, 'utf8');
    const iv = Buffer.from(ivString, 'utf8');
    
    // Pad the plaintext to be a multiple of 16 bytes
    const blockSize = 16;
    const padLength = blockSize - (plainText.length % blockSize);
    const paddedText = plainText + '\0'.repeat(padLength);
    
    const cipher = crypto.createCipheriv('aes-128-cbc', key, iv);
    cipher.setAutoPadding(false); // Equivalent to PaddingMode.None
    
    let encrypted = cipher.update(paddedText, 'utf8', 'base64');
    encrypted += cipher.final('base64');
    encryptedText = encrypted;
  } catch (e) {
    console.error("Error during encryption:", e.message);
    throw e;
  }

  console.log("Plain Text:", plainText);
  console.log("Encrypted Data:", encryptedText);

  // API Call
  try {
    const response = await axios.post(in_url, {
      encData: encryptedText
    }, {
      headers: {
        'Content-Type': 'application/json',
        'cache-control': 'no-cache'
        // Add other headers as needed
      }
    });

    const responseContent = response.data;
    console.log("API Response:", responseContent);

    // Extract encrypted response (assuming same format as C# code)
    let enc_res;
    if (typeof responseContent === 'string') {
      enc_res = responseContent.substring(11, responseContent.length - 2);
    } else if (responseContent.encData) {
      enc_res = responseContent.encData;
    } else {
      throw new Error("Unexpected response format");
    }

    // Decryption
    let decryptedText;
    try {
      const key = Buffer.from(encryptionkey, 'utf8');
      const iv = Buffer.from(ivString, 'utf8');
      
      const decipher = crypto.createDecipheriv('aes-128-cbc', key, iv);
      decipher.setAutoPadding(false);
      
      let decrypted = decipher.update(enc_res, 'base64', 'utf8');
      decrypted += decipher.final('utf8');
      decryptedText = decrypted.replace(/\0+$/, ''); // Trim null characters
    } catch (e) {
      console.error("Error during decryption:", e.message);
      throw e;
    }

    console.log("Decrypted Data:", decryptedText);
    return decryptedText;
  } catch (e) {
    console.error("API call failed:", e.message);
    throw e;
  }
}

// Example usage:
(async () => {
  try {
    const result = await callEncryptedApi({
      in_timestamp: new Date().toISOString(),
      in_req: "12345", // Your request ID
      in_acct_no: "ACCT123456", // Your account number
      in_url: "https://api.example.com/endpoint" // Your API endpoint
    });
    console.log("Final Result:", result);
  } catch (e) {
    console.error("Process failed:", e);
  }
})();